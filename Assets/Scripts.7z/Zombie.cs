using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zombie : MonoBehaviour
{
    Animation anim;
    public GameObject z_AttackPoint;
    Vector3 moveVec;
    float zomVec_X, zomVec_Z;
    

    public bool NormalZombie=true;
    public bool RunningZombie;
    void Start()
    {
        anim.GetComponent<Animator>();
        anim.wrapMode = WrapMode.Loop;// �ִϸ��̼� �ݺ�
    }

    void Update()
    {
        if (NormalZombie && !RunningZombie)
        {
            Idle();
            Move();
            Attack();
        }else if (!NormalZombie && RunningZombie)
        {
            Idle();
            Run();
            Attack();
        }


    }
    void Idle() {
        
        //anim.Play("Z_Idle");
    }
    void Move() {
        moveVec = new Vector3(zomVec_X, 0, zomVec_Z).normalized;
    }
    void Run() {

    }
    void Attack() {

    }
}
